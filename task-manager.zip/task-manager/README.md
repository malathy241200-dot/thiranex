# Taskboard - Task Management Application

A full-stack task manager.

- Frontend: React + Vite (plain CSS, responsive)
- Backend: FastAPI + SQLite + SQLAlchemy
- Login: JWT tokens, passwords hashed with bcrypt
- Real-time: WebSocket (open the app in two tabs and watch them sync)

## Folder layout

```
task-manager/
  backend/
    requirements.txt
    app/
      main.py               API routes + WebSocket
      auth.py               password hashing, JWT, current user
      database.py           SQLite connection
      models.py             User and Task tables
      schemas.py            request/response shapes
      websocket_manager.py  live update connections
  frontend/
    package.json, vite.config.js, index.html
    src/
      main.jsx, App.jsx, api.js, AuthContext.jsx, index.css
      pages/       Login.jsx, Register.jsx, Dashboard.jsx
      components/  TaskCard.jsx, TaskForm.jsx
```

## Run it (you need Python 3.10+ and Node.js 18+)

Open TWO terminals.

### Terminal 1 - backend

Windows:
```
cd task-manager/backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Mac / Linux:
```
cd task-manager/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### Terminal 2 - frontend

```
cd task-manager/frontend
npm install
npm run dev
```

Open http://localhost:5173

## API summary

| Method | URL | What it does |
|---|---|---|
| POST | /api/auth/register | create account |
| POST | /api/auth/login | log in, get token |
| GET | /api/auth/me | current user |
| GET | /api/tasks | list my tasks |
| POST | /api/tasks | create task |
| GET | /api/tasks/{id} | get one task |
| PUT | /api/tasks/{id} | update task |
| DELETE | /api/tasks/{id} | delete task |
| WS | /api/ws?token=... | live updates |

Every task route needs the header `Authorization: Bearer <token>`.
A user can only see and change their own tasks.
