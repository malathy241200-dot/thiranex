# Keeps track of open WebSocket connections so we can send live updates
from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        # user id -> list of that user's open connections (many tabs/devices)
        self.connections: dict[int, list[WebSocket]] = {}

    async def connect(self, user_id: int, websocket: WebSocket):
        await websocket.accept()
        self.connections.setdefault(user_id, []).append(websocket)

    def disconnect(self, user_id: int, websocket: WebSocket):
        sockets = self.connections.get(user_id, [])
        if websocket in sockets:
            sockets.remove(websocket)
        if not sockets:
            self.connections.pop(user_id, None)

    async def broadcast(self, user_id: int, message: dict):
        """Send a message to every open tab/device of one user."""
        for websocket in list(self.connections.get(user_id, [])):
            try:
                await websocket.send_json(message)
            except Exception:
                self.disconnect(user_id, websocket)


manager = ConnectionManager()
