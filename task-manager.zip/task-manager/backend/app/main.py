# The main FastAPI app: all API routes live here
from typing import Optional

from fastapi import (
    APIRouter, Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect, status,
)
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import or_
from sqlalchemy.orm import Session

from . import models, schemas
from .auth import (
    create_access_token, get_current_user, get_user_from_token,
    hash_password, verify_password,
)
from .database import Base, SessionLocal, engine, get_db
from .websocket_manager import manager

# Create the database tables if they do not exist yet
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Task Management API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

router = APIRouter(prefix="/api")


# ---------------------------------------------------------------- Auth
@router.post("/auth/register", response_model=schemas.Token, status_code=201)
def register(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    username = payload.username.strip().lower()
    if db.query(models.User).filter(models.User.username == username).first():
        raise HTTPException(status_code=400, detail="This username is already taken")
    user = models.User(username=username, hashed_password=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return schemas.Token(access_token=create_access_token(user.id), user=user)


@router.post("/auth/login", response_model=schemas.Token)
def login(payload: schemas.UserLogin, db: Session = Depends(get_db)):
    username = payload.username.strip().lower()
    user = db.query(models.User).filter(models.User.username == username).first()
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Wrong username or password")
    return schemas.Token(access_token=create_access_token(user.id), user=user)


@router.get("/auth/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    return current_user


# --------------------------------------------------------------- Tasks
def get_own_task(task_id: int, user: models.User, db: Session) -> models.Task:
    """Finds a task only if it belongs to the logged in user (authorization)."""
    task = (
        db.query(models.Task)
        .filter(models.Task.id == task_id, models.Task.owner_id == user.id)
        .first()
    )
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@router.get("/tasks", response_model=list[schemas.TaskOut])
def list_tasks(
    status_filter: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    query = db.query(models.Task).filter(models.Task.owner_id == current_user.id)
    if status_filter:
        query = query.filter(models.Task.status == status_filter)
    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(models.Task.title.ilike(like), models.Task.description.ilike(like))
        )
    return query.order_by(models.Task.created_at.desc()).all()


@router.post("/tasks", response_model=schemas.TaskOut, status_code=201)
async def create_task(
    payload: schemas.TaskCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    task = models.Task(**payload.model_dump(), owner_id=current_user.id)
    db.add(task)
    db.commit()
    db.refresh(task)
    await manager.broadcast(current_user.id, {"event": "task_created", "task_id": task.id})
    return task


@router.get("/tasks/{task_id}", response_model=schemas.TaskOut)
def get_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return get_own_task(task_id, current_user, db)


@router.put("/tasks/{task_id}", response_model=schemas.TaskOut)
async def update_task(
    task_id: int,
    payload: schemas.TaskUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    task = get_own_task(task_id, current_user, db)
    # exclude_unset: only change the fields the client actually sent
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(task, field, value)
    db.commit()
    db.refresh(task)
    await manager.broadcast(current_user.id, {"event": "task_updated", "task_id": task.id})
    return task


@router.delete("/tasks/{task_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    task = get_own_task(task_id, current_user, db)
    db.delete(task)
    db.commit()
    await manager.broadcast(current_user.id, {"event": "task_deleted", "task_id": task_id})


# ----------------------------------------------------------- WebSocket
@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str):
    db = SessionLocal()
    try:
        user = get_user_from_token(token, db)
        user_id = user.id if user else None
    finally:
        db.close()

    if user_id is None:
        await websocket.close(code=1008)  # 1008 = policy violation (bad token)
        return

    await manager.connect(user_id, websocket)
    try:
        while True:
            await websocket.receive_text()  # keep the connection open
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)


app.include_router(router)


@app.get("/")
def root():
    return {"message": "Task Management API is running. See /docs"}
