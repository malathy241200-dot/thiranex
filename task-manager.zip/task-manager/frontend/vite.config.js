import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The proxy sends every request that starts with /api to the FastAPI server
// (including the WebSocket), so the frontend never has to deal with CORS.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
        ws: true,
      },
    },
  },
});
