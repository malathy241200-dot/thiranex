import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../api.js";
import { useAuth } from "../AuthContext.jsx";
import TaskCard from "../components/TaskCard.jsx";
import TaskForm from "../components/TaskForm.jsx";

const COLUMNS = [
  { key: "todo", title: "To do", empty: "Nothing waiting. Add a task to get started." },
  { key: "in_progress", title: "In progress", empty: "Move a task here when you start it." },
  { key: "done", title: "Done", empty: "Finished tasks show up here." },
];

export default function Dashboard() {
  const { user, token, logout } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [live, setLive] = useState(false);
  const [search, setSearch] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [formTask, setFormTask] = useState(null); // task being edited
  const [showForm, setShowForm] = useState(false);

  const handleError = useCallback(
    (err) => {
      if (err.status === 401) logout(); // token expired
      else setError(err.message);
    },
    [logout]
  );

  const loadTasks = useCallback(async () => {
    try {
      setTasks(await api.getTasks());
      setError("");
    } catch (err) {
      handleError(err);
    }
    setLoading(false);
  }, [handleError]);

  // Load tasks when the page opens
  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  // Real-time updates: the server tells us when tasks change
  useEffect(() => {
    let socket;
    let retryTimer;
    let closedByUs = false;

    function connect() {
      const protocol = window.location.protocol === "https:" ? "wss" : "ws";
      socket = new WebSocket(
        `${protocol}://${window.location.host}/api/ws?token=${encodeURIComponent(token)}`
      );
      socket.onopen = () => setLive(true);
      socket.onmessage = () => loadTasks();
      socket.onclose = () => {
        setLive(false);
        if (!closedByUs) retryTimer = setTimeout(connect, 3000); // try again
      };
    }

    connect();
    return () => {
      closedByUs = true;
      clearTimeout(retryTimer);
      if (socket) socket.close();
    };
  }, [token, loadTasks]);

  // Search + priority filter happen in the browser
  const visibleTasks = useMemo(() => {
    const text = search.trim().toLowerCase();
    return tasks.filter((t) => {
      const matchesText =
        !text || t.title.toLowerCase().includes(text) || t.description.toLowerCase().includes(text);
      const matchesPriority = priorityFilter === "all" || t.priority === priorityFilter;
      return matchesText && matchesPriority;
    });
  }, [tasks, search, priorityFilter]);

  const doneCount = tasks.filter((t) => t.status === "done").length;

  async function handleSave(data) {
    if (formTask) await api.updateTask(formTask.id, data);
    else await api.createTask(data);
    setShowForm(false);
    setFormTask(null);
    loadTasks();
  }

  async function handleMove(task, newStatus) {
    try {
      await api.updateTask(task.id, { status: newStatus });
      loadTasks();
    } catch (err) {
      handleError(err);
    }
  }

  async function handleDelete(task) {
    if (!window.confirm(`Delete "${task.title}"? This cannot be undone.`)) return;
    try {
      await api.deleteTask(task.id);
      loadTasks();
    } catch (err) {
      handleError(err);
    }
  }

  function openNew() {
    setFormTask(null);
    setShowForm(true);
  }

  function openEdit(task) {
    setFormTask(task);
    setShowForm(true);
  }

  return (
    <div className="page">
      <header className="topbar">
        <div>
          <h1>Taskboard</h1>
          <p className="muted">
            {user.username} &middot; {doneCount} of {tasks.length} tasks done
          </p>
        </div>
        <div className="topbar-right">
          <span className={live ? "live on" : "live"} title="Real-time connection">
            {live ? "Live" : "Offline"}
          </span>
          <button className="btn" onClick={logout}>Log out</button>
        </div>
      </header>

      <section className="toolbar">
        <input type="search" placeholder="Search tasks" value={search}
          onChange={(e) => setSearch(e.target.value)} aria-label="Search tasks" />
        <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}
          aria-label="Filter by priority">
          <option value="all">All priorities</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <button className="btn primary" onClick={openNew}>Add task</button>
      </section>

      {error && <p className="error" role="alert">{error}</p>}
      {loading && <p className="center-note">Loading tasks...</p>}

      {!loading && (
        <main className="board">
          {COLUMNS.map((col) => {
            const items = visibleTasks.filter((t) => t.status === col.key);
            return (
              <section className="column" key={col.key}>
                <h2>
                  {col.title} <span className="count">{items.length}</span>
                </h2>
                {items.length === 0 && <p className="empty">{col.empty}</p>}
                {items.map((task) => (
                  <TaskCard key={task.id} task={task} onMove={handleMove}
                    onEdit={openEdit} onDelete={handleDelete} />
                ))}
              </section>
            );
          })}
        </main>
      )}

      {showForm && (
        <TaskForm task={formTask} onSave={handleSave}
          onCancel={() => { setShowForm(false); setFormTask(null); }} />
      )}
    </div>
  );
}
