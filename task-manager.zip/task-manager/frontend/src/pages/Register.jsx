import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext.jsx";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (username.trim().length < 3) return setError("Username needs at least 3 characters");
    if (password.length < 6) return setError("Password needs at least 6 characters");
    setBusy(true);
    try {
      await register(username, password);
      navigate("/");
    } catch (err) {
      setError(err.message);
    }
    setBusy(false);
  }

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>Create your account</h1>
        <p className="muted">Your tasks stay private to you.</p>

        {error && <p className="error" role="alert">{error}</p>}

        <label htmlFor="username">Username</label>
        <input id="username" value={username} onChange={(e) => setUsername(e.target.value)}
          autoComplete="username" required />

        <label htmlFor="password">Password (6+ characters)</label>
        <input id="password" type="password" value={password}
          onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required />

        <button className="btn primary" type="submit" disabled={busy}>
          {busy ? "Creating..." : "Create account"}
        </button>
        <p className="muted">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </main>
  );
}
