import { createContext, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setTokenState] = useState(getToken());
  const [loading, setLoading] = useState(true);

  // When the page loads, check if the saved token is still valid
  useEffect(() => {
    async function checkToken() {
      if (!getToken()) {
        setLoading(false);
        return;
      }
      try {
        setUser(await api.me());
      } catch {
        setToken(null);
        setTokenState(null);
      }
      setLoading(false);
    }
    checkToken();
  }, []);

  function saveSession(data) {
    setToken(data.access_token);
    setTokenState(data.access_token);
    setUser(data.user);
  }

  async function login(username, password) {
    saveSession(await api.login(username, password));
  }

  async function register(username, password) {
    saveSession(await api.register(username, password));
  }

  function logout() {
    setToken(null);
    setTokenState(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
