const STATUS_ORDER = ["todo", "in_progress", "done"];
const STATUS_LABEL = { todo: "To do", in_progress: "In progress", done: "Done" };

function formatDate(value) {
  // value looks like "2026-12-02"
  const [y, m, d] = value.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    day: "numeric", month: "short", year: "numeric",
  });
}

function isOverdue(task) {
  if (!task.due_date || task.status === "done") return false;
  const today = new Date();
  const todayText = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  return task.due_date < todayText;
}

export default function TaskCard({ task, onMove, onEdit, onDelete }) {
  const index = STATUS_ORDER.indexOf(task.status);
  const prev = STATUS_ORDER[index - 1];
  const next = STATUS_ORDER[index + 1];

  return (
    <article className={`card priority-${task.priority}`}>
      <h3>{task.title}</h3>
      {task.description && <p className="card-desc">{task.description}</p>}

      <p className="card-meta">
        <span className={`badge ${task.priority}`}>{task.priority} priority</span>
        {task.due_date && (
          <span className={isOverdue(task) ? "due overdue" : "due"}>
            {isOverdue(task) ? "Overdue: " : "Due "}
            {formatDate(task.due_date)}
          </span>
        )}
      </p>

      <div className="card-actions">
        {prev && (
          <button className="btn small" onClick={() => onMove(task, prev)}>
            Back to {STATUS_LABEL[prev]}
          </button>
        )}
        {next && (
          <button className="btn small primary" onClick={() => onMove(task, next)}>
            Move to {STATUS_LABEL[next]}
          </button>
        )}
        <button className="btn small" onClick={() => onEdit(task)}>Edit</button>
        <button className="btn small danger" onClick={() => onDelete(task)}>Delete</button>
      </div>
    </article>
  );
}
