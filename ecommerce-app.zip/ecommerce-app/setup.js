// Creates the database/tables and seeds an admin user + sample products.
require('dotenv').config();
const fs = require('fs');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  const dbName = process.env.DB_NAME || 'shop_db';
  let sql = fs.readFileSync('schema.sql', 'utf8').replace(/shop_db/g, dbName);
  await conn.query(sql);

  const email = process.env.ADMIN_EMAIL || 'admin@shop.com';
  const pass = process.env.ADMIN_PASSWORD || 'Admin@123';
  const hash = await bcrypt.hash(pass, 10);
  await conn.query(
    "INSERT IGNORE INTO users (name,email,password,role) VALUES ('Admin',?,?,'admin')",
    [email, hash]
  );

  const [[{ n }]] = await conn.query('SELECT COUNT(*) AS n FROM products');
  if (n === 0) {
    await conn.query(
      'INSERT INTO products (name,description,price,stock,category,image_url) VALUES ?',
      [[
        ['Wireless Headphones', 'Over-ear Bluetooth headphones with 30h battery.', 2499, 25, 'Electronics', 'https://picsum.photos/seed/headphones/400/300'],
        ['Mechanical Keyboard', 'Compact 75% keyboard with tactile switches.', 3299, 15, 'Electronics', 'https://picsum.photos/seed/keyboard/400/300'],
        ['Running Shoes', 'Lightweight everyday trainers.', 1899, 40, 'Fashion', 'https://picsum.photos/seed/shoes/400/300'],
        ['Steel Water Bottle', 'Insulated 750 ml bottle, keeps drinks cold 24h.', 599, 80, 'Home', 'https://picsum.photos/seed/bottle/400/300'],
        ['Backpack', '25L water-resistant laptop backpack.', 1499, 30, 'Fashion', 'https://picsum.photos/seed/backpack/400/300'],
        ['Desk Lamp', 'LED lamp with three colour temperatures.', 899, 20, 'Home', 'https://picsum.photos/seed/lamp/400/300']
      ]]
    );
  }
  console.log(`Database "${dbName}" ready. Admin login: ${email} / ${pass}`);
  await conn.end();
})().catch(e => { console.error('Setup failed:', e.message); process.exit(1); });
