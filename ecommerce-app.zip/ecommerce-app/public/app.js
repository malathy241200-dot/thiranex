// Corner Shop - single-page frontend (vanilla JS, hash routing)
const $app = document.getElementById('app');
const $nav = document.getElementById('nav');
const state = {
  token: localStorage.getItem('token'),
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  cart: JSON.parse(localStorage.getItem('cart') || '[]')
};
const money = n => '₹' + Number(n).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const saveCart = () => localStorage.setItem('cart', JSON.stringify(state.cart));
const cartCount = () => state.cart.reduce((n, i) => n + i.quantity, 0);

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

async function api(path, method = 'GET', body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && state.token) { logout(true); }
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function setSession(data) {
  state.token = data.token; state.user = data.user;
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
}
function logout(silent) {
  state.token = null; state.user = null;
  localStorage.removeItem('token'); localStorage.removeItem('user');
  if (!silent) toast('Logged out');
  location.hash = '#/login';
}

function renderNav() {
  const u = state.user;
  $nav.innerHTML = `
    <a href="#/">Shop</a>
    <a href="#/cart">Cart (${cartCount()})</a>
    ${u ? `<a href="#/orders">My orders</a>` : ''}
    ${u && u.role === 'admin' ? `<a href="#/admin/products">Manage products</a><a href="#/admin/orders">All orders</a>` : ''}
    ${u ? `<button id="out">Log out (${esc(u.name)})</button>` : `<a href="#/login">Log in</a><a href="#/register">Sign up</a>`}`;
  const out = document.getElementById('out');
  if (out) out.onclick = () => logout();
}

/* ---------- Shop ---------- */
async function viewShop() {
  $app.innerHTML = `<h1>Shop</h1>
    <div class="bar"><input id="q" type="search" placeholder="Search products">
    <select id="cat"><option value="">All categories</option></select></div>
    <div id="list" class="grid"></div>`;
  const all = await api('/products');
  const cats = [...new Set(all.map(p => p.category).filter(Boolean))];
  document.getElementById('cat').innerHTML += cats.map(c => `<option>${esc(c)}</option>`).join('');
  const draw = () => {
    const q = document.getElementById('q').value.toLowerCase();
    const c = document.getElementById('cat').value;
    const list = all.filter(p => (!c || p.category === c) && (p.name + p.description).toLowerCase().includes(q));
    document.getElementById('list').innerHTML = list.length ? list.map(p => `
      <div class="card"><img src="${esc(p.image_url)}" alt="${esc(p.name)}" loading="lazy" onerror="this.style.visibility='hidden'">
        <div class="body"><span class="tag">${esc(p.category)}</span><strong>${esc(p.name)}</strong>
        <span class="mute">${esc(p.description)}</span>
        <div class="row" style="margin-top:auto"><span class="price">${money(p.price)}</span>
        ${p.stock > 0 ? `<button class="btn right" data-add="${p.id}">Add to cart</button>` : `<span class="mute right">Out of stock</span>`}</div></div></div>`).join('')
      : `<p class="empty" style="grid-column:1/-1">No products match your search.</p>`;
    document.querySelectorAll('[data-add]').forEach(b => b.onclick = () => {
      const p = all.find(x => x.id == b.dataset.add);
      const line = state.cart.find(i => i.product_id === p.id);
      if (line) { if (line.quantity < p.stock) line.quantity++; else return toast('No more stock available'); }
      else state.cart.push({ product_id: p.id, name: p.name, price: Number(p.price), stock: p.stock, quantity: 1 });
      saveCart(); renderNav(); toast(`${p.name} added to cart`);
    });
  };
  document.getElementById('q').oninput = draw;
  document.getElementById('cat').onchange = draw;
  draw();
}

/* ---------- Cart & checkout ---------- */
function viewCart() {
  if (!state.cart.length) {
    $app.innerHTML = `<h1>Your cart</h1><p class="empty">Your cart is empty. <a href="#/">Browse products</a></p>`; return;
  }
  const total = state.cart.reduce((s, i) => s + i.price * i.quantity, 0);
  $app.innerHTML = `<h1>Your cart</h1>
    <div class="panel wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead><tbody>
    ${state.cart.map((i, n) => `<tr><td>${esc(i.name)}</td><td>${money(i.price)}</td>
      <td><span class="qty"><button data-dec="${n}" aria-label="Decrease">−</button>${i.quantity}<button data-inc="${n}" aria-label="Increase">+</button></span></td>
      <td>${money(i.price * i.quantity)}</td><td><button class="btn alt" data-rm="${n}">Remove</button></td></tr>`).join('')}
    </tbody></table><p class="price" style="text-align:right">Total: ${money(total)}</p></div>
    <div class="panel"><h2>Delivery address</h2>
    <textarea id="addr" rows="3" placeholder="House no, street, city, PIN code"></textarea>
    <p class="err" id="err"></p>
    <button class="btn" id="buy">Place order</button></div>`;
  const redraw = () => { saveCart(); renderNav(); viewCart(); };
  document.querySelectorAll('[data-inc]').forEach(b => b.onclick = () => { const i = state.cart[b.dataset.inc]; if (i.quantity < i.stock) i.quantity++; else toast('No more stock available'); redraw(); });
  document.querySelectorAll('[data-dec]').forEach(b => b.onclick = () => { const i = state.cart[b.dataset.dec]; if (--i.quantity < 1) state.cart.splice(b.dataset.dec, 1); redraw(); });
  document.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { state.cart.splice(b.dataset.rm, 1); redraw(); });
  document.getElementById('buy').onclick = async () => {
    if (!state.user) { toast('Log in to place your order'); location.hash = '#/login'; return; }
    try {
      const r = await api('/orders', 'POST', { items: state.cart.map(i => ({ product_id: i.product_id, quantity: i.quantity })), address: document.getElementById('addr').value });
      state.cart = []; saveCart(); renderNav();
      $app.innerHTML = `<div class="panel narrow"><h1>Order placed</h1><p>Your order #${r.id} for ${money(r.total)} is confirmed.</p><a class="btn" href="#/orders">Track your order</a></div>`;
    } catch (e) { document.getElementById('err').textContent = e.message; }
  };
}

/* ---------- Auth ---------- */
function viewAuth(mode) {
  const reg = mode === 'register';
  $app.innerHTML = `<div class="panel narrow"><h1>${reg ? 'Create your account' : 'Log in'}</h1><form id="f">
    ${reg ? `<label for="name">Name</label><input id="name" required>` : ''}
    <label for="email">Email</label><input id="email" type="email" required>
    <label for="pw">Password</label><input id="pw" type="password" required minlength="${reg ? 6 : 1}">
    <p class="err" id="err"></p><button class="btn" type="submit">${reg ? 'Sign up' : 'Log in'}</button></form>
    <p class="mute">${reg ? 'Have an account? <a href="#/login">Log in</a>' : 'New here? <a href="#/register">Create an account</a>'}</p></div>`;
  document.getElementById('f').onsubmit = async e => {
    e.preventDefault();
    try {
      const body = { email: document.getElementById('email').value, password: document.getElementById('pw').value };
      if (reg) body.name = document.getElementById('name').value;
      setSession(await api(reg ? '/auth/register' : '/auth/login', 'POST', body));
      toast('Welcome, ' + state.user.name);
      location.hash = state.user.role === 'admin' ? '#/admin/orders' : '#/';
    } catch (err) { document.getElementById('err').textContent = err.message; }
  };
}

/* ---------- Orders ---------- */
const orderCard = (o, admin) => `<div class="panel"><div class="row">
  <strong>Order #${o.id}</strong><span class="status ${o.status}">${o.status}</span>
  <span class="mute">${new Date(o.created_at).toLocaleString()}</span><span class="price right">${money(o.total)}</span></div>
  ${admin ? `<p class="mute">${esc(o.customer)} (${esc(o.email)})</p>` : ''}
  <p>${o.items.map(i => `${esc(i.name)} × ${i.quantity}`).join(', ')}</p>
  <p class="mute">Deliver to: ${esc(o.address)}</p>
  ${admin ? `<div class="row"><label for="s${o.id}" style="margin:0">Update status</label>
    <select id="s${o.id}" data-oid="${o.id}" style="width:auto">${['Placed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'].map(s => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>` : ''}</div>`;

async function viewOrders() {
  const orders = await api('/orders/mine');
  $app.innerHTML = `<h1>My orders</h1>` + (orders.length ? orders.map(o => orderCard(o, false)).join('') : `<p class="empty">No orders yet. <a href="#/">Start shopping</a></p>`);
}
async function viewAdminOrders() {
  const orders = await api('/orders');
  $app.innerHTML = `<h1>All orders</h1>` + (orders.length ? orders.map(o => orderCard(o, true)).join('') : `<p class="empty">No orders yet.</p>`);
  document.querySelectorAll('[data-oid]').forEach(s => s.onchange = async () => {
    try { await api(`/orders/${s.dataset.oid}/status`, 'PATCH', { status: s.value }); toast('Status updated'); viewAdminOrders(); }
    catch (e) { toast(e.message); }
  });
}

/* ---------- Admin: products ---------- */
async function viewAdminProducts() {
  const products = await api('/products');
  $app.innerHTML = `<h1>Manage products</h1>
    <div class="panel"><h2 id="ftitle">Add a product</h2><form id="pf" class="form2">
      <input type="hidden" id="pid">
      <div><label for="pn">Name</label><input id="pn" required></div>
      <div><label for="pc">Category</label><input id="pc"></div>
      <div><label for="pp">Price (₹)</label><input id="pp" type="number" min="0" step="0.01" required></div>
      <div><label for="ps">Stock</label><input id="ps" type="number" min="0" value="0" required></div>
      <div class="full"><label for="pi">Image URL</label><input id="pi" type="url"></div>
      <div class="full"><label for="pd">Description</label><textarea id="pd" rows="2"></textarea></div>
      <div class="full row" style="margin-top:12px"><button class="btn" type="submit">Save product</button>
      <button class="btn alt" type="button" id="clr">Clear</button><span class="err" id="err"></span></div></form></div>
    <div class="panel wrap"><table><thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th></th></tr></thead><tbody>
    ${products.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.category)}</td><td>${money(p.price)}</td><td>${p.stock}</td>
      <td class="row"><button class="btn alt" data-edit="${p.id}">Edit</button><button class="btn del" data-del="${p.id}">Delete</button></td></tr>`).join('')}
    </tbody></table></div>`;
  const $ = id => document.getElementById(id);
  const clear = () => { $('pf').reset(); $('pid').value = ''; $('ftitle').textContent = 'Add a product'; };
  $('clr').onclick = clear;
  $('pf').onsubmit = async e => {
    e.preventDefault();
    const body = { name: $('pn').value, category: $('pc').value, price: $('pp').value, stock: $('ps').value, image_url: $('pi').value, description: $('pd').value };
    try {
      $('pid').value ? await api('/products/' + $('pid').value, 'PUT', body) : await api('/products', 'POST', body);
      toast('Product saved'); viewAdminProducts();
    } catch (err) { $('err').textContent = err.message; }
  };
  document.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => {
    const p = products.find(x => x.id == b.dataset.edit);
    $('pid').value = p.id; $('pn').value = p.name; $('pc').value = p.category || ''; $('pp').value = p.price;
    $('ps').value = p.stock; $('pi').value = p.image_url || ''; $('pd').value = p.description || '';
    $('ftitle').textContent = 'Edit product'; scrollTo({ top: 0 });
  });
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
    if (!confirm('Delete this product?')) return;
    try { await api('/products/' + b.dataset.del, 'DELETE'); toast('Product deleted'); viewAdminProducts(); }
    catch (e) { toast(e.message); }
  });
}

/* ---------- Router ---------- */
const routes = {
  '/': { fn: viewShop },
  '/cart': { fn: viewCart },
  '/login': { fn: () => viewAuth('login') },
  '/register': { fn: () => viewAuth('register') },
  '/orders': { fn: viewOrders, login: true },
  '/admin/products': { fn: viewAdminProducts, admin: true },
  '/admin/orders': { fn: viewAdminOrders, admin: true }
};
async function route() {
  renderNav();
  const r = routes[location.hash.slice(1) || '/'] || routes['/'];
  if ((r.login || r.admin) && !state.user) { location.hash = '#/login'; return; }
  if (r.admin && state.user.role !== 'admin') { $app.innerHTML = `<p class="empty">This page is for admins only.</p>`; return; }
  try { await r.fn(); } catch (e) { $app.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
window.addEventListener('hashchange', route);
route();
