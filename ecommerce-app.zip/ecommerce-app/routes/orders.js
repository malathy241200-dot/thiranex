const router = require('express').Router();
const db = require('../db');
const { auth, adminOnly } = require('../middleware/auth');

const STATUSES = ['Placed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'];

async function withItems(orders) {
  for (const o of orders) {
    const [items] = await db.query(
      `SELECT oi.quantity, oi.price, p.name FROM order_items oi
       JOIN products p ON p.id = oi.product_id WHERE oi.order_id=?`, [o.id]);
    o.items = items;
  }
  return orders;
}

// Checkout: validates stock, creates order, reduces stock (one transaction)
router.post('/', auth, async (req, res) => {
  const { items, address } = req.body;
  if (!address || !address.trim()) return res.status(400).json({ error: 'Delivery address is required' });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Your cart is empty' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    let total = 0;
    const lines = [];
    for (const it of items) {
      const qty = parseInt(it.quantity, 10);
      if (!qty || qty < 1) throw new Error('Invalid quantity');
      const [rows] = await conn.query('SELECT id,name,price,stock FROM products WHERE id=? FOR UPDATE', [it.product_id]);
      const p = rows[0];
      if (!p) throw new Error('A product in your cart no longer exists');
      if (p.stock < qty) throw new Error(`Only ${p.stock} left of "${p.name}"`);
      total += Number(p.price) * qty;
      lines.push([p.id, qty, p.price]);
    }
    const [o] = await conn.query('INSERT INTO orders (user_id,total,address) VALUES (?,?,?)', [req.user.id, total, address.trim()]);
    for (const [pid, qty, price] of lines) {
      await conn.query('INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)', [o.insertId, pid, qty, price]);
      await conn.query('UPDATE products SET stock = stock - ? WHERE id=?', [qty, pid]);
    }
    await conn.commit();
    res.status(201).json({ id: o.insertId, total });
  } catch (e) {
    await conn.rollback();
    res.status(400).json({ error: e.message });
  } finally { conn.release(); }
});

// My orders
router.get('/mine', auth, async (req, res) => {
  const [rows] = await db.query('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC', [req.user.id]);
  res.json(await withItems(rows));
});

// Admin: all orders
router.get('/', auth, adminOnly, async (req, res) => {
  const [rows] = await db.query(
    `SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC`);
  res.json(await withItems(rows));
});

// Admin: update order status
router.patch('/:id/status', auth, adminOnly, async (req, res) => {
  const { status } = req.body;
  if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const [r] = await db.query('UPDATE orders SET status=? WHERE id=?', [status, req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Order not found' });
  res.json({ ok: true });
});

module.exports = router;
