const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { sign, auth } = require('../middleware/auth');

router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    const [exists] = await db.query('SELECT id FROM users WHERE email=?', [email]);
    if (exists.length) return res.status(409).json({ error: 'Email is already registered' });
    const hash = await bcrypt.hash(password, 10);
    const [r] = await db.query("INSERT INTO users (name,email,password,role) VALUES (?,?,?,'user')", [name, email, hash]);
    const user = { id: r.insertId, name, role: 'user' };
    res.status(201).json({ token: sign(user), user });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await db.query('SELECT * FROM users WHERE email=?', [email]);
    const u = rows[0];
    if (!u || !(await bcrypt.compare(password || '', u.password)))
      return res.status(401).json({ error: 'Wrong email or password' });
    const user = { id: u.id, name: u.name, role: u.role };
    res.json({ token: sign(user), user });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

router.get('/me', auth, (req, res) => res.json({ user: req.user }));

module.exports = router;
