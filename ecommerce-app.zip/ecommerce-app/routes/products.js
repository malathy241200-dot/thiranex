const router = require('express').Router();
const db = require('../db');
const { auth, adminOnly } = require('../middleware/auth');

function validate(b) {
  if (!b.name || b.price === undefined || isNaN(b.price) || Number(b.price) < 0) return 'Name and a valid price are required';
  if (b.stock !== undefined && (isNaN(b.stock) || Number(b.stock) < 0)) return 'Stock must be 0 or more';
  return null;
}

// Public: list / search / filter
router.get('/', async (req, res) => {
  try {
    const { q, category } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const args = [];
    if (q) { sql += ' AND (name LIKE ? OR description LIKE ?)'; args.push(`%${q}%`, `%${q}%`); }
    if (category) { sql += ' AND category=?'; args.push(category); }
    const [rows] = await db.query(sql + ' ORDER BY id DESC', args);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM products WHERE id=?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Product not found' });
  res.json(rows[0]);
});

// Admin: create / update / delete
router.post('/', auth, adminOnly, async (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ error: err });
  const { name, description, price, stock, category, image_url } = req.body;
  const [r] = await db.query(
    'INSERT INTO products (name,description,price,stock,category,image_url) VALUES (?,?,?,?,?,?)',
    [name, description || '', price, stock || 0, category || '', image_url || '']
  );
  res.status(201).json({ id: r.insertId });
});

router.put('/:id', auth, adminOnly, async (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ error: err });
  const { name, description, price, stock, category, image_url } = req.body;
  const [r] = await db.query(
    'UPDATE products SET name=?,description=?,price=?,stock=?,category=?,image_url=? WHERE id=?',
    [name, description || '', price, stock || 0, category || '', image_url || '', req.params.id]
  );
  if (!r.affectedRows) return res.status(404).json({ error: 'Product not found' });
  res.json({ ok: true });
});

router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const [r] = await db.query('DELETE FROM products WHERE id=?', [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'Product not found' });
    res.json({ ok: true });
  } catch (e) {
    res.status(409).json({ error: 'Product is part of existing orders. Set its stock to 0 instead.' });
  }
});

module.exports = router;
