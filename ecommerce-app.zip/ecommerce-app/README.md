# Corner Shop – E-Commerce Web Application

Full-stack online store with product management, cart and checkout, order tracking and role-based access (Admin / User).

**Stack:** Node.js + Express (REST API) · MySQL · JWT auth (bcrypt password hashing) · HTML/CSS/vanilla JS frontend served by Express

## Features
- Product catalog with search and category filter
- Cart (saved in browser), checkout with delivery address
- Register / login; roles: `user` and `admin`
- Admin: add, edit, delete products; view all orders; update order status (Placed → Packed → Shipped → Delivered / Cancelled)
- User: view own orders and live status
- Checkout runs in a database transaction: stock is checked and reduced atomically

## Setup
1. Install Node.js 18+ and MySQL 8+.
2. `npm install`
3. Copy `.env.example` to `.env` and set `DB_PASSWORD` and `JWT_SECRET`.
4. `npm run setup` – creates the database, tables, an admin user and sample products.
5. `npm start` – open http://localhost:3000

**Default admin:** `admin@shop.com` / `Admin@123` (change in `.env` before running setup).

## API
| Method | Endpoint | Access |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/auth/me | logged in |
| GET | /api/products, /api/products/:id | public |
| POST / PUT / DELETE | /api/products, /api/products/:id | admin |
| POST | /api/orders | logged in |
| GET | /api/orders/mine | logged in |
| GET | /api/orders | admin |
| PATCH | /api/orders/:id/status | admin |

Send the token as `Authorization: Bearer <token>`.

## Database (4 tables)
`users` → `orders` (user_id) → `order_items` (order_id, product_id) → `products`. See `schema.sql`.

## Folder structure
```
server.js  db.js  setup.js  schema.sql
routes/      auth.js  products.js  orders.js
middleware/  auth.js (JWT + admin check)
public/      index.html  style.css  app.js
```
