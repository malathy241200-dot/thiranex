// Inkwell - single-page blog frontend (vanilla JS, hash routing)
const $app = document.getElementById('app');
const $nav = document.getElementById('nav');
const state = {
  token: localStorage.getItem('token'),
  user: JSON.parse(localStorage.getItem('user') || 'null')
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = d => new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const $ = id => document.getElementById(id);

function toast(msg) {
  const t = $('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

async function api(path, method = 'GET', body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && state.token) logout(true);
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function setSession(d) {
  state.token = d.token; state.user = d.user;
  localStorage.setItem('token', d.token);
  localStorage.setItem('user', JSON.stringify(d.user));
}
function logout(silent) {
  state.token = null; state.user = null;
  localStorage.removeItem('token'); localStorage.removeItem('user');
  if (!silent) toast('Logged out');
  location.hash = '#/login';
}

function renderNav() {
  const u = state.user;
  $nav.innerHTML = `<a href="#/">All posts</a>` + (u
    ? `<a href="#/mine">My posts</a><a href="#/new">Write a post</a><button id="out">Log out (${esc(u.name)})</button>`
    : `<a href="#/login">Log in</a><a href="#/register">Sign up</a>`);
  if ($('out')) $('out').onclick = () => logout();
}

/* ---------- Post lists ---------- */
function postItem(p) {
  return `<article class="post"><h2><a href="#/post/${p.id}">${esc(p.title)}</a></h2>
    <p class="mute">By ${esc(p.author)} · ${when(p.created_at)} · ${p.comment_count} comment${p.comment_count == 1 ? '' : 's'}</p>
    <p>${esc(p.excerpt)}${p.excerpt.length >= 220 ? '…' : ''}</p></article>`;
}

async function viewList(mine) {
  $app.innerHTML = `<h1>${mine ? 'My posts' : 'Latest posts'}</h1>
    ${mine ? '' : '<input id="q" class="search" type="search" placeholder="Search posts">'}<div id="list"></div>`;
  const load = async () => {
    const q = $('q') ? $('q').value.trim() : '';
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (mine) params.set('author', state.user.id);
    const posts = await api('/posts?' + params);
    $('list').innerHTML = posts.length ? posts.map(postItem).join('')
      : `<p class="empty">${mine ? 'You have not written anything yet. <a href="#/new">Write your first post</a>' : 'No posts found.'}</p>`;
  };
  if ($('q')) { let t; $('q').oninput = () => { clearTimeout(t); t = setTimeout(load, 250); }; }
  await load();
}

/* ---------- Single post + comments ---------- */
async function viewPost(id) {
  const [p, comments] = await Promise.all([api('/posts/' + id), api(`/posts/${id}/comments`)]);
  const u = state.user;
  const owner = u && u.id === p.user_id;
  $app.innerHTML = `<article><h1>${esc(p.title)}</h1>
    <p class="mute">By ${esc(p.author)} · ${when(p.created_at)}${p.updated_at !== p.created_at ? ' · edited ' + when(p.updated_at) : ''}</p>
    <div class="body">${esc(p.content)}</div>
    ${owner || (u && u.role === 'admin') ? `<div class="row">
      ${owner ? `<a class="btn alt" href="#/edit/${p.id}">Edit post</a>` : ''}
      <button class="btn del" id="delp">Delete post</button></div>` : ''}</article>
    <h2>Comments (${comments.length})</h2>
    <div id="clist">${comments.length ? comments.map(c => `<div class="comment">
      <div class="row"><strong>${esc(c.author)}</strong><span class="mute">${when(c.created_at)}</span>
      ${u && (u.id === c.user_id || owner || u.role === 'admin') ? `<button class="btn del sm" data-dc="${c.id}" style="margin-left:auto">Delete</button>` : ''}</div>
      <p>${esc(c.content)}</p></div>`).join('') : '<p class="mute">No comments yet. Start the conversation.</p>'}</div>
    ${u ? `<form id="cf"><label for="ct">Add a comment</label><textarea id="ct" rows="3" maxlength="1000" required></textarea>
      <p class="err" id="err"></p><button class="btn" type="submit">Post comment</button></form>`
      : `<p><a href="#/login">Log in</a> to join the discussion.</p>`}`;
  if ($('delp')) $('delp').onclick = async () => {
    if (!confirm('Delete this post and all its comments?')) return;
    try { await api('/posts/' + id, 'DELETE'); toast('Post deleted'); location.hash = '#/'; } catch (e) { toast(e.message); }
  };
  document.querySelectorAll('[data-dc]').forEach(b => b.onclick = async () => {
    try { await api('/comments/' + b.dataset.dc, 'DELETE'); toast('Comment deleted'); viewPost(id); } catch (e) { toast(e.message); }
  });
  if ($('cf')) $('cf').onsubmit = async e => {
    e.preventDefault();
    try { await api(`/posts/${id}/comments`, 'POST', { content: $('ct').value }); toast('Comment posted'); viewPost(id); }
    catch (err) { $('err').textContent = err.message; }
  };
}

/* ---------- Create / edit ---------- */
async function viewEditor(id) {
  let p = { title: '', content: '' };
  if (id) {
    p = await api('/posts/' + id);
    if (p.user_id !== state.user.id) { $app.innerHTML = '<p class="empty">You can only edit your own posts.</p>'; return; }
  }
  $app.innerHTML = `<h1>${id ? 'Edit post' : 'Write a post'}</h1><form id="pf">
    <label for="t">Title</label><input id="t" maxlength="200" required value="${esc(p.title)}">
    <label for="c">Content</label><textarea id="c" rows="14" required>${esc(p.content)}</textarea>
    <p class="err" id="err"></p>
    <div class="row"><button class="btn" type="submit">${id ? 'Save changes' : 'Publish'}</button><a class="btn alt" href="#/${id ? 'post/' + id : ''}">Cancel</a></div></form>`;
  $('pf').onsubmit = async e => {
    e.preventDefault();
    const body = { title: $('t').value, content: $('c').value };
    try {
      const r = id ? await api('/posts/' + id, 'PUT', body) : await api('/posts', 'POST', body);
      toast(id ? 'Changes saved' : 'Post published');
      location.hash = '#/post/' + (id || r.id);
    } catch (err) { $('err').textContent = err.message; }
  };
}

/* ---------- Auth ---------- */
function viewAuth(mode) {
  const reg = mode === 'register';
  $app.innerHTML = `<div class="panel narrow"><h1>${reg ? 'Create your account' : 'Log in'}</h1><form id="f">
    ${reg ? '<label for="name">Name</label><input id="name" required>' : ''}
    <label for="email">Email</label><input id="email" type="email" required>
    <label for="pw">Password</label><input id="pw" type="password" required minlength="${reg ? 6 : 1}">
    <p class="err" id="err"></p><button class="btn" type="submit">${reg ? 'Sign up' : 'Log in'}</button></form>
    <p class="mute">${reg ? 'Have an account? <a href="#/login">Log in</a>' : 'New here? <a href="#/register">Create an account</a>'}</p></div>`;
  $('f').onsubmit = async e => {
    e.preventDefault();
    const body = { email: $('email').value, password: $('pw').value };
    if (reg) body.name = $('name').value;
    try {
      setSession(await api(reg ? '/auth/register' : '/auth/login', 'POST', body));
      toast('Welcome, ' + state.user.name); location.hash = '#/';
    } catch (err) { $('err').textContent = err.message; }
  };
}

/* ---------- Router ---------- */
async function route() {
  renderNav();
  const [, page, id] = (location.hash.slice(1) || '/').split('/');
  const needLogin = ['mine', 'new', 'edit'];
  if (needLogin.includes(page) && !state.user) { location.hash = '#/login'; return; }
  try {
    if (!page) await viewList(false);
    else if (page === 'mine') await viewList(true);
    else if (page === 'post') await viewPost(id);
    else if (page === 'new') await viewEditor();
    else if (page === 'edit') await viewEditor(id);
    else if (page === 'login') viewAuth('login');
    else if (page === 'register') viewAuth('register');
    else await viewList(false);
  } catch (e) { $app.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
window.addEventListener('hashchange', route);
route();
