# Inkwell – Blog Platform with Comments

Full-stack blogging platform where users register, write posts and discuss them in comments.

**Stack:** Node.js + Express (REST API) · MySQL · JWT auth (bcrypt password hashing) · HTML/CSS/vanilla JS frontend served by Express

## Features
- Registration, login and token-based authentication
- Create, edit and delete posts (only the author can edit; author or admin can delete)
- Search posts, "My posts" page
- Comments on every post; a comment can be deleted by its author, the post's author, or an admin
- Anyone can read; login is needed to write or comment

## Setup
1. Install Node.js 18+ and MySQL 8+.
2. `npm install`
3. Copy `.env.example` to `.env` and set `DB_PASSWORD` and `JWT_SECRET`.
4. `npm run setup` – creates the database, tables, an admin user and a welcome post.
5. `npm start` – open http://localhost:3000

**Default admin:** `admin@blog.com` / `Admin@123`

## API
| Method | Endpoint | Access |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/auth/me | logged in |
| GET | /api/posts?q=&author= | public |
| GET | /api/posts/:id | public |
| POST | /api/posts | logged in |
| PUT | /api/posts/:id | post author |
| DELETE | /api/posts/:id | post author or admin |
| GET | /api/posts/:id/comments | public |
| POST | /api/posts/:id/comments | logged in |
| DELETE | /api/comments/:id | comment author, post author or admin |

Send the token as `Authorization: Bearer <token>`.

## Database (3 tables)
`users` → `posts` (user_id) → `comments` (post_id, user_id). See `schema.sql`. Deleting a post removes its comments.

## Folder structure
```
server.js  db.js  setup.js  schema.sql
routes/      auth.js  posts.js  comments.js
middleware/  auth.js (JWT check)
public/      index.html  style.css  app.js
```
