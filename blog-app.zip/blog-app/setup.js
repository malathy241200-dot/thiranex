// Creates the database/tables and seeds an admin user + a welcome post.
require('dotenv').config();
const fs = require('fs');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  const dbName = process.env.DB_NAME || 'blog_db';
  await conn.query(fs.readFileSync('schema.sql', 'utf8').replace(/blog_db/g, dbName));

  const email = process.env.ADMIN_EMAIL || 'admin@blog.com';
  const pass = process.env.ADMIN_PASSWORD || 'Admin@123';
  await conn.query(
    "INSERT IGNORE INTO users (name,email,password,role) VALUES ('Admin',?,?,'admin')",
    [email, await bcrypt.hash(pass, 10)]
  );
  const [[{ n }]] = await conn.query('SELECT COUNT(*) AS n FROM posts');
  if (n === 0) {
    const [[admin]] = await conn.query('SELECT id FROM users WHERE email=?', [email]);
    await conn.query('INSERT INTO posts (user_id,title,content) VALUES (?,?,?)', [
      admin.id,
      'Welcome to the blog',
      'This is the first post. Sign up, write your own posts, and join the conversation in the comments below.'
    ]);
  }
  console.log(`Database "${dbName}" ready. Admin login: ${email} / ${pass}`);
  await conn.end();
})().catch(e => { console.error('Setup failed:', e.message); process.exit(1); });
