const router = require('express').Router();
const db = require('../db');
const { auth } = require('../middleware/auth');

function validate(b) {
  const title = (b.title || '').trim(), content = (b.content || '').trim();
  if (!title || !content) return 'Title and content are required';
  if (title.length > 200) return 'Title must be 200 characters or fewer';
  return null;
}

// Public: list posts (optional ?q= search, ?author=<user id>)
router.get('/', async (req, res) => {
  try {
    const { q, author } = req.query;
    let sql = `SELECT p.id, p.title, LEFT(p.content, 220) AS excerpt, p.created_at, p.user_id,
               u.name AS author, (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count
               FROM posts p JOIN users u ON u.id=p.user_id WHERE 1=1`;
    const args = [];
    if (q) { sql += ' AND (p.title LIKE ? OR p.content LIKE ?)'; args.push(`%${q}%`, `%${q}%`); }
    if (author) { sql += ' AND p.user_id=?'; args.push(author); }
    const [rows] = await db.query(sql + ' ORDER BY p.created_at DESC', args);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.query(
    `SELECT p.*, u.name AS author FROM posts p JOIN users u ON u.id=p.user_id WHERE p.id=?`, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Post not found' });
  res.json(rows[0]);
});

router.post('/', auth, async (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ error: err });
  const [r] = await db.query('INSERT INTO posts (user_id,title,content) VALUES (?,?,?)',
    [req.user.id, req.body.title.trim(), req.body.content.trim()]);
  res.status(201).json({ id: r.insertId });
});

// Only the author can edit
router.put('/:id', auth, async (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ error: err });
  const [rows] = await db.query('SELECT user_id FROM posts WHERE id=?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Post not found' });
  if (rows[0].user_id !== req.user.id) return res.status(403).json({ error: 'You can only edit your own posts' });
  await db.query('UPDATE posts SET title=?, content=? WHERE id=?', [req.body.title.trim(), req.body.content.trim(), req.params.id]);
  res.json({ ok: true });
});

// Author or admin can delete
router.delete('/:id', auth, async (req, res) => {
  const [rows] = await db.query('SELECT user_id FROM posts WHERE id=?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Post not found' });
  if (rows[0].user_id !== req.user.id && req.user.role !== 'admin')
    return res.status(403).json({ error: 'You can only delete your own posts' });
  await db.query('DELETE FROM posts WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// ---- Comments on a post ----
router.get('/:id/comments', async (req, res) => {
  const [rows] = await db.query(
    `SELECT c.id, c.content, c.created_at, c.user_id, u.name AS author
     FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.created_at ASC`, [req.params.id]);
  res.json(rows);
});

router.post('/:id/comments', auth, async (req, res) => {
  const content = (req.body.content || '').trim();
  if (!content) return res.status(400).json({ error: 'Comment cannot be empty' });
  if (content.length > 1000) return res.status(400).json({ error: 'Comment must be 1000 characters or fewer' });
  const [p] = await db.query('SELECT id FROM posts WHERE id=?', [req.params.id]);
  if (!p.length) return res.status(404).json({ error: 'Post not found' });
  const [r] = await db.query('INSERT INTO comments (post_id,user_id,content) VALUES (?,?,?)', [req.params.id, req.user.id, content]);
  res.status(201).json({ id: r.insertId });
});

module.exports = router;
