const router = require('express').Router();
const db = require('../db');
const { auth } = require('../middleware/auth');

// Comment author, the post's author, or an admin can delete a comment
router.delete('/:id', auth, async (req, res) => {
  const [rows] = await db.query(
    `SELECT c.user_id, p.user_id AS post_owner FROM comments c JOIN posts p ON p.id=c.post_id WHERE c.id=?`, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Comment not found' });
  const { user_id, post_owner } = rows[0];
  if (req.user.id !== user_id && req.user.id !== post_owner && req.user.role !== 'admin')
    return res.status(403).json({ error: 'You cannot delete this comment' });
  await db.query('DELETE FROM comments WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
