require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const { connectDB } = require('./db');
const Project = require('./models/Project');

(async () => {
  if (!(await connectDB())) {
    console.error('Set MONGODB_URI in your .env file first.');
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'projects.json'), 'utf8'));
  await Project.deleteMany({});
  await Project.insertMany(data);
  console.log(`Seeded ${data.length} projects.`);
  await mongoose.disconnect();
})();
