// ---------- Helpers ----------
const $ = (sel) => document.querySelector(sel);

function escapeHTML(str = '') {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// Only allow http(s) links coming from the database
function safeUrl(url = '') {
  return /^https?:\/\//i.test(url) ? escapeHTML(url) : '';
}

// ---------- Theme toggle ----------
const root = document.documentElement;
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
  root.setAttribute('data-theme', savedTheme);
} else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
  root.setAttribute('data-theme', 'dark');
}

$('#themeToggle').addEventListener('click', () => {
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
});

// ---------- Mobile menu ----------
const navLinks = $('#navLinks');
const navToggle = $('#navToggle');
navToggle.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(open));
});
navLinks.addEventListener('click', (e) => {
  if (e.target.tagName === 'A') {
    navLinks.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  }
});

// ---------- Projects (fetched from the backend / database) ----------
let allProjects = [];

function renderProjects(list) {
  const grid = $('#projectGrid');
  if (!list.length) {
    grid.innerHTML = '<p class="muted">No projects found.</p>';
    return;
  }
  grid.innerHTML = list.map((p) => {
    const github = safeUrl(p.githubUrl);
    const live = safeUrl(p.liveUrl);
    return `
      <article class="project-card">
        ${p.featured ? '<span class="badge">Featured</span>' : ''}
        <h3>${escapeHTML(p.title)}</h3>
        <p>${escapeHTML(p.description)}</p>
        <ul class="chips">${(p.tech || []).map((t) => `<li>${escapeHTML(t)}</li>`).join('')}</ul>
        <div class="links">
          ${github ? `<a href="${github}" target="_blank" rel="noopener">Code</a>` : ''}
          ${live ? `<a href="${live}" target="_blank" rel="noopener">Live demo</a>` : ''}
        </div>
      </article>`;
  }).join('');
}

function renderFilters(projects) {
  const techs = [...new Set(projects.flatMap((p) => p.tech || []))].sort();
  const box = $('#filters');
  box.innerHTML = ['All', ...techs]
    .map((t, i) => `<button class="filter-btn${i === 0 ? ' active' : ''}" data-tech="${escapeHTML(t)}">${escapeHTML(t)}</button>`)
    .join('');

  box.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    box.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const tech = btn.dataset.tech;
    renderProjects(tech === 'All' ? allProjects : allProjects.filter((p) => (p.tech || []).includes(tech)));
  });
}

async function loadProjects() {
  try {
    const res = await fetch('/api/projects');
    if (!res.ok) throw new Error('Request failed');
    const data = await res.json();
    allProjects = data.projects || [];
    renderFilters(allProjects);
    renderProjects(allProjects);
  } catch (err) {
    $('#projectGrid').innerHTML = '<p class="muted">Could not load projects right now. Please try again later.</p>';
  }
}

// ---------- Contact form ----------
$('#contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const status = $('#formStatus');
  const button = form.querySelector('button');
  const body = Object.fromEntries(new FormData(form));

  status.className = 'form-status';
  status.textContent = '';

  if (!body.name.trim() || !body.email.trim() || !body.message.trim()) {
    status.classList.add('err');
    status.textContent = 'Please fill in all fields.';
    return;
  }

  button.disabled = true;
  button.textContent = 'Sending…';
  try {
    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    status.classList.add('ok');
    status.textContent = data.message;
    form.reset();
  } catch (err) {
    status.classList.add('err');
    status.textContent = err.message;
  } finally {
    button.disabled = false;
    button.textContent = 'Send message';
  }
});

// ---------- Reveal on scroll ----------
const observer = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (en.isIntersecting) {
      en.target.classList.add('visible');
      observer.unobserve(en.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

// ---------- Init ----------
$('#year').textContent = new Date().getFullYear();
loadProjects();
