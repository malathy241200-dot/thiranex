const express = require('express');
const fs = require('fs');
const path = require('path');
const { connectDB } = require('../db');
const Project = require('../models/Project');
const Message = require('../models/Message');

const router = express.Router();

// Fallback data so the site still works before MongoDB is configured
function loadFallbackProjects() {
  const file = path.join(__dirname, '..', 'data', 'projects.json');
  return JSON.parse(fs.readFileSync(file, 'utf8')).map((p, i) => ({ _id: `local-${i}`, ...p }));
}

// Simple admin guard for write operations
function requireAdmin(req, res, next) {
  const key = process.env.ADMIN_KEY;
  if (!key || req.get('x-admin-key') !== key) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

// ---------- Projects ----------

// GET /api/projects  (optional ?tech=React)
router.get('/projects', async (req, res) => {
  try {
    const connected = await connectDB();
    let projects = connected
      ? await Project.find().sort({ order: 1, createdAt: -1 }).lean()
      : loadFallbackProjects();

    if (req.query.tech) {
      const t = String(req.query.tech).toLowerCase();
      projects = projects.filter((p) => p.tech.some((x) => x.toLowerCase() === t));
    }
    res.json({ source: connected ? 'database' : 'local-file', projects });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load projects' });
  }
});

// POST /api/projects  (admin)
router.post('/projects', requireAdmin, async (req, res) => {
  try {
    if (!(await connectDB())) return res.status(503).json({ error: 'Database not configured' });
    const project = await Project.create(req.body);
    res.status(201).json(project);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /api/projects/:id  (admin)
router.put('/projects/:id', requireAdmin, async (req, res) => {
  try {
    if (!(await connectDB())) return res.status(503).json({ error: 'Database not configured' });
    const project = await Project.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/projects/:id  (admin)
router.delete('/projects/:id', requireAdmin, async (req, res) => {
  try {
    if (!(await connectDB())) return res.status(503).json({ error: 'Database not configured' });
    const project = await Project.findByIdAndDelete(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------- Contact form ----------

// POST /api/contact
router.post('/contact', async (req, res) => {
  const { name, email, message } = req.body || {};

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email and message are required.' });
  }
  if (!isEmail(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }
  if (String(message).length > 2000) {
    return res.status(400).json({ error: 'Message is too long (max 2000 characters).' });
  }

  try {
    if (await connectDB()) {
      await Message.create({ name, email, message });
    } else {
      // No database configured: log so nothing is silently lost during development
      console.log('Contact message (DB not configured):', { name, email, message });
    }
    res.status(201).json({ ok: true, message: 'Thanks! Your message has been received.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not send your message. Please try again.' });
  }
});

// GET /api/messages  (admin) - read messages people sent through the form
router.get('/messages', requireAdmin, async (req, res) => {
  try {
    if (!(await connectDB())) return res.status(503).json({ error: 'Database not configured' });
    res.json(await Message.find().sort({ createdAt: -1 }).lean());
  } catch (err) {
    res.status(500).json({ error: 'Could not load messages' });
  }
});

// Health check
router.get('/health', (req, res) => res.json({ status: 'ok' }));

module.exports = router;
