# Personal Portfolio Website (Full-Stack)

A full-stack portfolio that showcases projects and skills.

| Layer      | Technology                                   |
|------------|----------------------------------------------|
| Frontend   | HTML, CSS, vanilla JavaScript                |
| Backend    | Node.js + Express.js (REST API)              |
| Database   | MongoDB (Mongoose)                           |
| Deployment | Vercel (config included) or Render / Heroku  |

## Features

- Responsive single-page design with dark/light mode
- Projects are **stored in MongoDB** and loaded through `GET /api/projects`
- Filter projects by technology
- Contact form saves messages to the database (`POST /api/contact`) with validation
- Admin-protected endpoints to add, edit and delete projects without touching code
- Works even before MongoDB is connected (falls back to `data/projects.json`)

## Project structure

```
portfolio/
├── server.js            # Express app entry point
├── db.js                # MongoDB connection (serverless friendly)
├── seed.js              # Loads data/projects.json into MongoDB
├── routes/api.js        # API routes
├── models/              # Mongoose models (Project, Message)
├── data/projects.json   # Your project data (edit this!)
├── public/              # Frontend (index.html, css/, js/)
├── vercel.json          # Vercel deployment config
└── .env.example         # Environment variable template
```

## Run locally

1. Install [Node.js](https://nodejs.org) 18 or newer.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create your env file and fill it in:
   ```bash
   cp .env.example .env
   ```
   - `MONGODB_URI`: from a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster
     (Connect, then Drivers, then copy the connection string and add your password).
     For local MongoDB use `mongodb://127.0.0.1:27017/portfolio`.
   - `ADMIN_KEY`: any long random string.
4. Load your projects into the database:
   ```bash
   npm run seed
   ```
5. Start the server and open http://localhost:3000
   ```bash
   npm start
   ```

## Personalise it (do this before submitting)

1. `public/index.html`: replace "Your Name", the about text, skills, and the GitHub / LinkedIn / email links in the footer.
2. `data/projects.json`: replace the sample projects with your real ones, then run `npm run seed` again.
3. Change the `YN` logo initials in the nav and the page `<title>`.
4. Colours live in the `:root` block at the top of `public/css/style.css`.

## API reference

| Method | Endpoint             | Description                          | Auth        |
|--------|----------------------|--------------------------------------|-------------|
| GET    | `/api/projects`      | List projects (`?tech=React` filter) | Public      |
| POST   | `/api/projects`      | Add a project                        | `x-admin-key` |
| PUT    | `/api/projects/:id`  | Update a project                     | `x-admin-key` |
| DELETE | `/api/projects/:id`  | Delete a project                     | `x-admin-key` |
| POST   | `/api/contact`       | Send a contact message               | Public      |
| GET    | `/api/messages`      | Read received messages               | `x-admin-key` |
| GET    | `/api/health`        | Health check                         | Public      |

Example, adding a project:

```bash
curl -X POST http://localhost:3000/api/projects \
  -H "Content-Type: application/json" \
  -H "x-admin-key: YOUR_ADMIN_KEY" \
  -d '{"title":"My App","description":"What it does","tech":["Node.js","MongoDB"],"githubUrl":"https://github.com/you/my-app"}'
```

## Deploy

### Option A: Vercel (config already included)

1. Push this folder to a GitHub repository.
2. Go to [vercel.com](https://vercel.com), choose **Add New, Project**, and import the repo.
3. Under **Environment Variables** add `MONGODB_URI` and `ADMIN_KEY`.
4. Click **Deploy**. Your live URL will look like `https://your-project.vercel.app`.
5. In MongoDB Atlas, open **Network Access** and allow `0.0.0.0/0` so Vercel can connect.

### Option B: Render (runs Express as a normal server)

1. Push to GitHub, then create a new **Web Service** on [render.com](https://render.com).
2. Build command: `npm install`, start command: `npm start`.
3. Add the same environment variables and deploy.

> Netlify only hosts static files, so use Vercel or Render for this full-stack version.

## Submission checklist

- [ ] Personal details and projects replaced
- [ ] MongoDB connected and seeded
- [ ] Deployed and live link works (projects load, contact form saves)
- [ ] Code pushed to GitHub with this README
