const mongoose = require('mongoose');

let connecting = null;

/**
 * Connects to MongoDB once and reuses the connection (works on serverless too).
 * Returns true if connected, false if no URI is set or the connection failed.
 */
async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) return false;
  if (mongoose.connection.readyState === 1) return true;

  if (!connecting) {
    connecting = mongoose
      .connect(uri, { serverSelectionTimeoutMS: 8000 })
      .then(() => {
        console.log('MongoDB connected');
        return true;
      })
      .catch((err) => {
        console.error('MongoDB connection failed:', err.message);
        connecting = null;
        return false;
      });
  }
  return connecting;
}

module.exports = { connectDB };
