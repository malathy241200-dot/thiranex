require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./routes/api');
const { connectDB } = require('./db');

const app = express();

app.use(cors());
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api', apiRoutes);

// Unknown API routes -> JSON 404
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

const PORT = process.env.PORT || 3000;

// On Vercel the app is exported as a serverless handler; elsewhere we start a server.
if (!process.env.VERCEL) {
  connectDB().finally(() => {
    app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
  });
}

module.exports = app;
